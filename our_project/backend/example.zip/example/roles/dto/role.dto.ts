import { ApiProperty } from "@nestjs/swagger";

export class RoleDto {
	@ApiProperty({example: 'ADMIN', description: 'Роль пользователя'})
	readonly value: string;
	
	@ApiProperty({example: 'Администратор', description: 'Описание роли пользователя'})
	readonly discription: string;
}