import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { RolesModel } from '../models/roles.model'
import { RoleDto } from './dto/role.dto'

@Injectable()
export class RolesService {
	constructor (@InjectModel(RolesModel) private rolesRepository: typeof RolesModel) {}

	async createRole(roleUser: RoleDto) {
		const Role = await this.rolesRepository.create(roleUser);
		return Role;
	}

	async getRoleByValue(value: string) {
		const Role = await this.rolesRepository.findOne({where: {value}});
		return Role;
	}

	async getRoles() {
		const Roles = await this.rolesRepository.findAll();
		return Roles;
	}

/*	async addRelations(newRelations: UserRoleRelationsDto) {
		const User = await 
		const Roles = await this.rolesRepository.findAll();
		return Roles;
	}*/
}
