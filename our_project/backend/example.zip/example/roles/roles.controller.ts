import { Controller, Post, Body, Get, Param } from '@nestjs/common';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { RolesModel } from 'src/models/roles.model'
import { RolesService } from './roles.service';
import { RoleDto } from './dto/role.dto';

@ApiTags('Работа с ролями')
@Controller('roles')
export class RolesController {

	constructor(private readonly service:RolesService) {}

	@ApiOperation({summary: 'Создание Роли'})
	@ApiResponse({status: 200, type: RolesModel})
	@Post()
	createRole(@Body() newRole: RoleDto) {
		return this.service.createRole(newRole);
	}

	@ApiOperation({summary: 'Данные о заданной роли'})
	@ApiResponse({status: 200, type: RolesModel})
	@Get('/add_role/:value')
	getRoleByValue(@Param('value') value: string) {
		return this.service.getRoleByValue(value);
	}

	@ApiOperation({summary: 'Данные о ролях'})
	@ApiResponse({status: 200, type: [RolesModel]})
	@Get('/all_roles')
	getRoles() {
		return this.service.getRoles();
	}

/*	@ApiOperation({summary: 'Добавление роли пользователю'})
	@ApiResponse({status: 200, type: UserRoleDto})
	@Post('/add_relations')
	addRelations(@Body() newRelations: UserRoleRelationsDto) {
		return this.service.addRelations(newRelations);
	}*/

}
