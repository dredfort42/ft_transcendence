import { Column, DataType, ForeignKey, Model, Table } from "sequelize-typescript";
import { RolesModel } from './roles.model'
import { UsersModel } from './users.model'

@Table({tableName:'users_roles', createdAt: false, updatedAt: false})
export class UsersRolesModel extends Model<UsersRolesModel> {
	@Column({type: DataType.INTEGER, unique: true, autoIncrement: true, primaryKey: true})
	id: number;

	@ForeignKey(() => RolesModel)
	@Column({type: DataType.INTEGER})
	roleId: number;

	@ForeignKey(() => UsersModel)
	@Column({type: DataType.INTEGER})
	userId: number;
}