import { ApiProperty } from "@nestjs/swagger";
import { Column, DataType, Model, Table, BelongsToMany } from "sequelize-typescript";
import { RoleDto } from "../roles/dto/role.dto"
import { UsersRolesModel } from "./users-roles.model"
import { UsersModel } from "./users.model"

@Table({tableName:'roles'})
export class RolesModel extends Model<RolesModel, RoleDto> {
	@ApiProperty({example: 1, description: 'Уникальный идентификатор'})
	@Column({type: DataType.INTEGER, unique: true, autoIncrement: true, primaryKey: true})
	id: number;

	@ApiProperty({example: 'ADMIN', description: 'Роль пользователя'})
	@Column({type: DataType.STRING, unique: true, allowNull: false})
	value: string;

	@ApiProperty({example: 'Администратор', description: 'Описание роли пользователя'})
	@Column({type: DataType.STRING, defaultValue: ''})
	discription: string;

	@BelongsToMany(()=>UsersModel, ()=>UsersRolesModel)
	users: UsersModel[]
}