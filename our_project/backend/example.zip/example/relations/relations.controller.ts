import { Controller, Post, Body } from '@nestjs/common';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { RelationsService } from './relations.service';
import { UsersRolesModel } from 'src/models/users-roles.model';
import { UserRoleRelationsDto } from './dto/relation.dto'

@ApiTags('Назначение прав пользователям')
@Controller('relations')
export class RelationsController {

	constructor(private readonly service:RelationsService) {}

	@ApiOperation({summary: 'Добавление роли пользователю'})
	@ApiResponse({status: 200, type: UsersRolesModel})
	@Post()
	createUser(@Body() newRelations: UserRoleRelationsDto) {
		return this.service.createRelations(newRelations);
	}


}
