import { ApiProperty } from "@nestjs/swagger";

export class UserRoleRelationsDto {
	@ApiProperty({example: '1', description: 'Ссылка на пользователя'})
	readonly userId: number;
	
	@ApiProperty({example: '1', description: 'Ссылка на роль'})
	readonly roleId: number;
}

export class UserRoleDto {
	@ApiProperty({example: 'user@mail.com', description: 'Email пользователя'})
	readonly email: string;
	
	@ApiProperty({example: 'ADMIN', description: 'Роль пользователя'})
	readonly value: string;
}