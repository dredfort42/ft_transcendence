import { Module } from '@nestjs/common';
import { SequelizeModule } from '@nestjs/sequelize';
import { RelationsService } from './relations.service';
import { RelationsController } from './relations.controller';
import { UsersRolesModel } from 'src/models/users-roles.model';
import { UsersModule } from 'src/users/users.module';
import { RolesModule } from 'src/roles/roles.module';

@Module({
	providers: [RelationsService],
	controllers: [RelationsController],
	imports: [
		SequelizeModule.forFeature([UsersRolesModel]),
		RolesModule,
		UsersModule
	],
})
export class RelationsModule {}
