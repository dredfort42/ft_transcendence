import { Injectable, HttpException, HttpStatus } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { UsersRolesModel } from 'src/models/users-roles.model'
import { UsersService } from 'src/users/users.service';
import { RolesService } from 'src/roles/roles.service';
import { UserRoleRelationsDto } from './dto/relation.dto'

@Injectable()
export class RelationsService {
	constructor (
		@InjectModel(UsersRolesModel) private relationsRepository: typeof UsersRolesModel,
		private roleService: RolesService,
		private userService: UsersService
	) {}

	async createRelations(newRelations: UserRoleRelationsDto) {
		let UserRelations = null;
		try {
			UserRelations = await this.relationsRepository.create(newRelations);
		} catch (err) {
			throw new HttpException('Forbidden', HttpStatus.FORBIDDEN);
		}

		return UserRelations;
	}
}
