import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { RolesService } from 'src/roles/roles.service';
import { UsersModel } from '../models/users.model'
import { UserDto } from './dto/user.dto'
import { RolesModel } from 'src/models/roles.model'

@Injectable()
export class UsersService {
	constructor (
		@InjectModel(UsersModel) private usersRepository: typeof UsersModel, 
		private roleService: RolesService
	) {}

	async createUser(newUser: UserDto) {
		const User = await this.usersRepository.create(newUser);
		const Role = await this.roleService.getRoleByValue('USER');
		if (Role != null)
			await User.$set('roles', Role.id);
		return User;
	}

	async getAllUsers() {
		const Users = await this.usersRepository.findAll({include: RolesModel, order: [['id','ASC']]});
		return Users;
	}

	async getUserByEmail(email: string) {
		const User = await this.usersRepository.findOne({where: {email}});
		return User;
	}
	
}
