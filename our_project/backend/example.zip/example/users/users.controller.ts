import { Controller, Post, Body, Get, Param } from '@nestjs/common';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { UsersModel } from '../models/users.model'
import { UsersService } from './users.service';
import { UserDto } from './dto/user.dto';

@ApiTags('Работа с пользователями')
@Controller('users')
export class UsersController {

	constructor(private readonly service:UsersService) {}

	@ApiOperation({summary: 'Создание пользователя'})
	@ApiResponse({status: 200, type: UsersModel})
	@Post()
	createUser(@Body() newUser: UserDto) {
		return this.service.createUser(newUser);
	}

	@ApiOperation({summary: 'Данные о пользователях'})
	@ApiResponse({status: 200, type: [UsersModel]})
	@Get()
	getAllUsers() {
		return this.service.getAllUsers();
	}
}
