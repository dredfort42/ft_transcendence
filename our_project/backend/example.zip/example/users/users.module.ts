import { Module } from '@nestjs/common';
import { SequelizeModule } from '@nestjs/sequelize';
import { UsersController } from './users.controller';
import { UsersModel } from '../models/users.model';
import { UsersService } from './users.service';
import { RolesModule } from 'src/roles/roles.module';

@Module({
	controllers: [UsersController],
	providers: [UsersService],
	imports: [
		SequelizeModule.forFeature([UsersModel]),
		RolesModule
	],
	exports: [UsersService]
})
export class UsersModule {}
